// const puppeteer = require("puppeteer");
import puppeteer from "puppeteer";
// import request from "request";
import request from "request-promise-native";

// var request = require("request");

function waitforme(millisec) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve("");
    }, millisec);
  });
}
async function runScript(puppeteer, request) {
  //   console.log("tetet");
  let profileData = JSON.stringify({
    profileData: {
      Timezone: {
        fill_timezone_based_on_ip: "false",
        timezone_offset: "-05:00",
        timezone_name: "America/New_York",
      },
      general_profile_information: {
        profile_browser_version: "129",
        simulated_operating_system: "windows",
        profile_name: "test",
        //   browser_id: '33ee196a-c125-4a8c-91f1-06f0a098d399',
        profile_notes: "None",
        profile_group: "Flexy",
        profile_last_edited: "2024-11-03",
      },
      Proxy: {
        connection_type: "HTTP proxy",
        proxy_rotation_api_url: "",
        proxy_username:
          "joaogtonew1-zone-resi-region-us-session-1a78b36001d5-sessTime-4",
        proxy_rotating: 0,
        proxy_provider: "main-ipinfo",
        proxy_url: "acacc76f85c8e994.ika.na.pyproxy.io:16666",
        proxy_password: "perco24",
      },
      // Geolocation: {
      //   fill_geolocation_based_on_ip: 'true',
      //   behavior: 'Prompt',
      //   location_information: {
      //     latitude: '42.41106',
      //     accuracy: '2100.0',
      //     longitude: '-71.37133'
      //   }
      // },
      Navigator: {
        navigator_languageIPToggle: true,
        hardware_concurrency: "SIX",
        languages: "en_US",
        do_not_track: false,
        screen_resolution: "1920x1080",
        navigator_useragent_always_latest: true,
        user_agent:
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.137 Safari/537.36",
        platform: "Win32",
        navigator_deviceMemory: "4",
        navigator_useragent_match_chrome_core: false,
      },
      // Media_devices: {
      //   audio_outputs: 4,
      //   video_outputs: 4,
      //   enable_media_masking: 'true',
      //   audio_inputs: 1
      // },
      // CustomDNS: { customDNS_enabled: 'false', customDNS_details: '' },
      // Fonts: {
      //   browser_font_list: 'Q2FsaWJyaSBMaWdodCxGYW50YXNxdWUgU2FucyBNb25vLENhbmRhcmEgTGlnaHQsVGltZXMgTmV3IFJvbWFuLFN5bGZhZW4sWXUgR290aGljLE1vbm9zcGFjZWQsTWljcm9zb2Z0IFlhSGVpIFVJIExpZ2h0LEVicmltYSxTZWdvZSBTY3JpcHQsTHVjaWRhIEdyYW5kZSxTZWdvZSBVSSBWYXJpYWJsZSxDYW5kYXJhLEFyaWFsSGVicmV3LUxpZ2h0LE1pY3Jvc29mdCBKaGVuZ0hlaSBMaWdodCxCZWxsIE1ULE1pY3Jvc29mdCBZYUhlaSBMaWdodCxOU2ltU3VuLE1WIEJvbGksWXUgR290aGljIFVJIFNlbWlib2xkLE5pcm1hbGEgVUkgU2VtaWxpZ2h0LExvYnN0ZXIsU2Vnb2UgVUkgU2VtaWxpZ2h0LFNlZ29lIFVJIExpZ2h0LFRhaG9tYSxDYW50YXJlbGwsSW5rIEZyZWUsTm90byxHZW9yZ2lhLE1pY3Jvc29mdCBOZXcgVGFpIEx1ZSxQYWxhdGluby1Cb2xkLEdlbmV2YSxTZWdvZSBVSSBIaXN0b3JpYyxNaWNyb3NvZnQgWWFIZWkgVUksQmlyY2ggU3RkLEZyYW5rbGluIEdvdGhpYyBNZWRpdW0sTHVjaWRhIENvbnNvbGUsUE1pbmdMaVUtRXh0QixQYWxhdGlubyxTZWdvZSBVSSBTeW1ib2wsUm9ib3RvLENvbnN0YW50aWEsQ2FsaWJyaSxOaXJtYWxhIFVJLEFyaWFsIEJsYWNrLENvdXJpZXIsQWxOaWxlLERyb2lkIFNlcmlmLENhbWJyaWEsVHJlYnVjaGV0IE1TLE1hbGd1biBHb3RoaWMgU2VtaWxpZ2h0LENvbWljIE5ldWUsTWljcm9zb2Z0IFNhbnMgU2VyaWYsTWluZ0xpVS1FeHRCLENlbnR1cnksVEktTnNwaXJlLENvcmJlbCBMaWdodCxTZWdvZSBVSSBTZW1pYm9sZCxBZG9iZSBCcmFpbGxlLEFwcGxlIEdvdGhpYyxTb3VyY2UgU2FucyBQcm8sR2FkdWdpLFNlZ29lIFVJIEVtb2ppLEdhYnJpb2xhLE1TIEdvdGhpYyxTYW5zIFNlcmlmIENvbGxlY3Rpb24sU2ltU3VuLFVidW50dSBSZWd1bGFyLENvbWljIFNhbnMgTVMsTW9uYWNvLFBhbGF0aW5vIExpbm90eXBlLERpYWxvZyxNeWFubWFyIFRleHQsWXUgR290aGljIFVJIExpZ2h0LE9zd2FsZCxKYXZhbmVzZSBUZXh0LEltcGFjdCxDb25zb2xhcyxVYnVudHUgTWVkaXVtLEFkb2JlIEhlYnJldyxNYWxndW4gR290aGljLEF2ZW5pciBOZXh0LFl1IEdvdGhpYyBVSSxBcmlhbCxNb25nb2xpYW4gQmFpdGksUGFweXJ1cyxDYW1icmlhIE1hdGgsU2Vnb2UgUHJpbnQsQ291cmllciBOZXcsTVMgUEdvdGhpYyxNaWNyb3NvZnQgWWFIZWksWXUgR290aGljIExpZ2h0LEFwcGxlIExpR290aGljLEJhaG5zY2hyaWZ0LE1pY3Jvc29mdCBIaW1hbGF5YSxPcGVuIFNhbnMsQ29yYmVsLEZ1dHVyYSxNaWNyb3NvZnQgVGFpIExlLFN5bWJvbCxEYW1hc2N1cyxNaWNyb3NvZnQgSmhlbmdIZWkgVUksV2ViZGluZ3MsTWFybGV0dCxIZWx2ZXRpY2EgTmV1ZSxTZWdvZSBGbHVlbnQgSWNvbnMsTWluZ0xpVV9IS1NDUy1FeHRCLFNpdGthIFRleHQsTWljcm9zb2Z0IFlpIEJhaXRpLEx1Y2lkYSBTYW5zIFVuaWNvZGUsVmVyZGFuYSxEaWFsb2dJbnB1dCxNaWNyb3NvZnQgUGhhZ3NQYSxRdWlja3NhbmQsTWluaW9uIFBybyxTZWdvZSBNREwyIEFzc2V0cyxNaWNyb3NvZnQgSmhlbmdIZWksTWljcm9zb2Z0IEpoZW5nSGVpIFVJIExpZ2h0LE5ldyBZb3JrLFNhbnNTZXJpZixZdSBHb3RoaWMgTWVkaXVtLEJhdGFuZyxDb3JzaXZhIEhlYnJldyxTaW1TdW4tRXh0QixXaW5nZGluZ3MsQXJpYWwgVW5pY29kZSBNUyxTZWdvZSBVSSxDZW50dXJ5IEdvdGhpYyxMYXRvLFRpbWVzLEF2ZW5pcixTZWdvZSBVSSBSZWd1bGFy',
      //   enable_font_list_masking: 'true',
      //   enable_unicode_glyps_domrect: 'false'
      // },
      // Hardware: {
      //   WebGL: { WebGL_meta: [Object], WebGL_image: [Object] },
      //   Canvas: {
      //     Canvas_hash: 'OsWgL2TaTBvA4w9POmsGqNsdORe6QFyzsZX4LFGbMXu1iwsmWNuvzNddtGWi0YB',
      //     Canvas_behavior: 'Off'
      //   },
      //   AudioContext: {
      //     AudioContext_hash: 'c5IzEGCQcNkiQdWIN0jYunvx0eY2egkmrKVUDvQRhnqYVQL0Neu1VQYfrmGqZ2Z',
      //     Audio_Context_behavior: 'Noise'
      //   }
      // },
      // Extensions: { contains_extensions: 'false' },
      WebRTC: {
        local_ip: "192.168.179.11",
        public_ip: "",
        behavior: "Altered",
        set_external_ip: true,
      },
      Other: {
        browser_allowRealMediaDevices: "false",
        other_try_to_pass_iphey: "false",
        active_session_lock: "true",
        other_ShowProfileName: "true",
        custom_browser_args_enabled: "false",
        browser_language_lock: "true",
        custom_browser_language: "",
        custom_browser_args_string: "",
        other_doNotShowChromeSettings: "false",
      },
    },
  });

  const options = {
    url: "http://localhost:35000/profile/add",
    method: "POST",
    json: true,
    headers: {
      "Content-Type": "application/json",
    },
    body: { profileData },
  };

  let dataRes = await request(options, async (error, response, body) => {
    if (!error && response.statusCode === 200) {
      console.log("Profile created successfully:", body.profile_browser_id);
      // '0df90c0e-d85d-408e-9b7e-8f437921bd57'
      return body;
    } else {
      console.error("Error creating profile:", error || body);
    }
  });
  var incognitonProfileID = dataRes.profile_browser_id;
  // var incognitonProfileID = "0df90c0e-d85d-408e-9b7e-8f437921bd57";

  var url =
    "http://localhost:35000/automation/launch/puppeteer/" + incognitonProfileID;
  // 35000
  async function sleepFor(sleepDuration) {
    var now = new Date().getTime();
    while (new Date().getTime() < now + sleepDuration) {}
  }

  function waitforme(millisec) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve("");
      }, millisec);
    });
  }

  async function actions(body, incognitonProfileID) {
    await sleepFor(3000); //Some time for the browser to actually start.
    
    if (!body.puppeteerUrl) {
      console.error("Error: puppeteerUrl is not defined in the response body.");
      return;
    }
    try {
      return await (async () => {
        const browserURL = body.puppeteerUrl;
        const browser = await puppeteer.connect({
          browserURL,
        });
        const page = await browser.newPage();
        // Set the viewport size (which controls the window size)

        try {
          await page.goto("https://searchtabs.io/joaonew.php", {
            timeout: 60000,
          });
          await page.setViewport({
            width: 1920,
            height: 1080,
          });
          const client = await page.target().createCDPSession();
          await client.send("Network.clearBrowserCache");
          await client.send("Network.clearBrowserCookies");
          try {
            // Get the iframe element
            const iframeElement = await page.$("iframe#master-1");

            // Access the content of the iframe
            const frame = await iframeElement.contentFrame();

            // Extract all website links from the adBlock div
            await frame.waitForSelector("#adBlock");
            await waitforme(2000);
            const links = await frame.evaluate(() => {
              // Select the main container
              const adContainer = document.querySelector("#adBlock");

              // Find all anchor tags inside the container and get their href attributes
              return Array.from(
                adContainer.querySelectorAll("a.p_.styleable-title.a")
              )
                .map((anchor) => anchor.href)
                .filter((href) => href.includes("http"));
            });

            //   console.log("links", links); // Outputs all collected links
            for (let i = 0; i < links.length; i++) {
              const newpage = await browser.newPage();
              await newpage.setViewport({
                width: 900,
                height: 1080,
              });
              try {
                await newpage.goto(links[i], {
                  timeout: 100000,
                });

                const scrollPageLikeHuman = async (page) => {
                  let previousHeight = 0;
                  let maxScrollAttempts = 20; // Set a maximum number of attempts to reach the end

                  for (
                    let attempt = 0;
                    attempt < maxScrollAttempts;
                    attempt++
                  ) {
                    // Scroll a random amount between 200 to 400 pixels
                    const scrollStep = Math.floor(Math.random() * 200) + 200;

                    await page.evaluate((step) => {
                      window.scrollBy(0, step);
                    }, scrollStep);

                    // Wait for a random time between 300ms and 800ms before scrolling again
                    const pauseDuration = Math.floor(Math.random() * 500) + 300;
                    //   await page.waitForTimeout(pauseDuration);
                    await waitforme(pauseDuration);
                    if (previousHeight === 0) {
                      await waitforme(5000);
                    }
                    // Get the current scroll height and compare it with the previous
                    const currentHeight = await page.evaluate(
                      () => document.body.scrollHeight
                    );

                    if (previousHeight === currentHeight) {
                      // Increment attempts if no new height is detected
                      attempt++;
                    } else {
                      attempt = 0; // Reset attempts if we’re still scrolling down
                    }

                    previousHeight = currentHeight;

                    // If the page height stops increasing, break out of the loop
                    if (attempt >= maxScrollAttempts) break;
                  }
                };

                // Usage
                await scrollPageLikeHuman(newpage);

                await waitforme(3000);
                await newpage.close();
              } catch (e) {
                console.log("Website has failed to load, moving to the next website....");
              }

              const pauseDuration = Math.floor(Math.random() * 8000) + 5000;
              console.log("pauseDurationNewTab", pauseDuration/1000 + " seconds");
              await waitforme(pauseDuration);
            }
          } catch (e) {
            console.log("error", e);
          }

          await browser.close();

          let deleteUrl = `http://localhost:35000/profile/delete/${incognitonProfileID}`;
          // console.log("du", deleteUrl);
          await request(
            {
              url: deleteUrl,
            },
            async function (error, response, body) {
              if (!error && response.statusCode === 200) {
                console.log("resbody", body);
              }
            }
          );
          //   return;
        } catch (e) {
          // continue
          await browser.close();
        }
      })();

      //   return
    } catch (err) {
      console.error(err);
    }

    // return;
  }

  let res = await request(
    {
      url: url,
      json: true,
      headers: {
        "Content-Type": "application/json",
      },
    },
    async function (error, response, body) {
    //   console.log("bodyres", body);
      if (!error && response.statusCode === 200) {
        // await actions(body, incognitonProfileID);
        return body
      }
    }
  );
  await actions(res, incognitonProfileID);
//   console.log("dataRes", dataRes,res);
//   return;
}

while (true) {
  await runScript(puppeteer, request);
  const pauseDuration = Math.floor(Math.random() * 50000) + 100000;
  console.log("Sleeping for", pauseDuration / 1000 + " seconds Zzzz..");
  await waitforme(pauseDuration);
}
